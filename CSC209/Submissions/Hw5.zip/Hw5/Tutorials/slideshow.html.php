
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP Slideshow</title>

    <style>
        /* Styling */
        img {
            width: 150px;
            height: auto;
            margin: 5px;
        }
    </style>
</head>

<body>

<!-- creates a paragraph with an id for the dom to locate and insert images -->
<p id="imageList"></p>

<?php

// locates all images in the images folder.
$jpg = glob("images/*.jpg");

// puts the JPG files that were combined from the glob into an array
$images = array_merge($jpg);

// empty string to store the html for the images
$htmlContent = "";

// loops through each image in the array
for ($i = 0; $i < count($images); $i++) {

    // appends an html image tag using the file path to the existing htmlContent string
    $htmlContent .= '<img src="' . $images[$i] . '"><br>';
}

?>

<script>

// uses the dom to locate and get access to the html paragraph with id imageList 
const paragraph = document.getElementById("imageList");

// php converts the htmlContent into a js string using json_encode(), then innerHTML inserts the image tags into the paragraph
paragraph.innerHTML = <?php echo json_encode($htmlContent); ?>;

</script>

</body>
</html>